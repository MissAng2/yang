$(function(){
    $("html,body").animate({scrollTop:"500"},1000)
})

// 下划线
$(".tit_name li").eq(0).css({
    borderBottom: "2px solid #327DF1",
    color: "#327DF1"
})
$(".tit_name li").click(function(){
    $(this).css({
        borderBottom: "2px solid #327DF1",
        color: "#327DF1"
    }).siblings().css({
        border: "none",
        color: "#78828C",
    })
})
// 鼠标箭头样式
$(".tit_name li").mouseenter(function(){
    this.style.cursor="pointer"
})
$(".pagelist li").mouseenter(function(){
    this.style.cursor="pointer"
})

// 分页按钮样式
$(".pagenav").eq(2).css({
    color: "#fff",
    backgroundColor: "#327DF1",
})
$(".pagenav").eq(3).css({
    color: "#666",
})
$(".pagenav").eq(4).css({
    color: "#666",
})
$(".pagenav").eq(5).css({
    color: "#666",
})

// 跳转
$(".pagelist li").eq(3).click(function(){
    $(location).prop("href","case1-2.html");
})
$(".pagelist li").eq(4).click(function(){
    $(location).prop("href","case1-2.html");
})
$(".pagelist li").eq(5).click(function(){
    $(location).prop("href","case1-2.html");
})