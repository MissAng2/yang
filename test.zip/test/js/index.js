//$(function(){
//  $("html,body").animate({scrollTop:"0"},1000)
//})

// 导航栏二级菜单
$(".navMenu").css({
    display: "none",
})
$(".navMenu").eq(1).css({
    height: "70px",
})
$(".navMenu").eq(2).css({
    height: "70px",
})
$(".ali").mouseenter(function(){
    var index=$(this).index();
    $(".navMenu").eq(index).css({
        display: "block",
    }).siblings(".navMenu").css({
        display: "none",
    })
    $(".navMenu").mouseenter(function(){
        $(".navMenu").eq(index).css({
            display: "block",
        }).siblings(".navMenu").css({
            display: "none",
        })
    })
    $(".navMenu").mouseleave(function(){
        $(".navMenu").css({
            display: "none",
        })
    })
})
$(".ali").mouseleave(function(){
    $(".navMenu").css({
        display: "none",
    })
})

$(".navMenuL").css("display","none")
$(".alin").mouseenter(function(){
    $(".navMenuL").css("display","block");
    $(".navMenuL").mouseenter(function(){
        $(".navMenuL").css("display","block");
    })
    $(".navMenuL").mouseleave(function(){
        $(".navMenuL").css("display","none");
    })
})
$(".alin").mouseleave(function(){
    $(".navMenuL").css("display","none")
})


// 四个小盒子

$(".imgLink").mouseenter(function(){
    var i=$(this).index();
    var imgSrc="../images/show_hardware_"+Number(i+1)+"_h.png";
    $(this).find("img").attr("src",imgSrc);
    $(this).children(".imgbox").css({
        color: "#FFFFFF",
    })
    $(this).find(".imgDis").css("opacity","1");
    
})
$(".imgLink").eq(0).mouseenter(function(){
	$(this).children(".imgbox").css({
    	backgroundColor: "#19C2D7",
    })
})
$(".imgLink").eq(1).mouseenter(function(){
	$(this).children(".imgbox").css({
    	backgroundColor: "#0CABF3",
    })
})
$(".imgLink").eq(2).mouseenter(function(){
	$(this).children(".imgbox").css({
    	backgroundColor: "#3D84F2",
    })
})
$(".imgLink").eq(3).mouseenter(function(){
	$(this).children(".imgbox").css({
    	backgroundColor: "#3D84F2",
    })
})
$(".imgLink").mouseleave(function(){
    var i=$(this).index();
    var imgSrc="../images/show_hardware_"+Number(i+1)+".png";
    $(this).find("img").attr("src",imgSrc);
    $(this).children(".imgbox").css({
        backgroundColor: "#FFFFFF",
        color: "#2C3D4F",
    })
    $(this).find(".imgDis").css("opacity","0.7");
})
// $(".imgbox").eq(0).mouseenter(function(){
//     $(this).find("img").attr("src","../images/show_hardware_1_h.png");
// })
// $(".imgbox").eq(0).mouseleave(function(){
//     $(this).find("img").attr("src","../images/show_hardware_1.png");
// })


// 第二个图片块背景色
$(".softtxt").eq(1).css({
    backgroundColor: "#2095F2"
})

// 浅灰色背景
$(".container").eq(3).css({
    paddingBottom: "60px",
})

// 返回顶部
$(window).scroll(function(){
    if($(window).scrollTop()>200){
        $(".back").css("display","block");
        $(".back").mouseenter(function(){
            $(".back img").attr("src","../images/go_up_h.png");
        })
        $(".back").mouseleave(function(){
            $(".back img").attr("src","../images/go_up.png");
        })
    }else{
        $(".back").css("display","none")
    }
})
$(".back").click(function(){
    $("html,body").animate({scrollTop:0},1000);
})

// 了解更多按钮设置
$(".btnDownload").eq(1).css({
    marginTop: "30px"
})

// 交换机跳转页面
$(".imgLink").eq(2).click(function(){
    $(location).prop("href","jiaohuanji.html");
})




// 点击logo回到首页
$("header .navbar-header img").click(function(){
    $(location).prop("href","index.html");
})


// 改变指针样式
$("header .navbar-header img").mouseenter(function(){
    this.style.cursor="pointer"
})

$(".imgLink").mouseenter(function(){
    this.style.cursor="pointer"
})





//应用案例读取json文件

$.ajax({
	url: "http://10.10.72.9:8080/demo.json",
	success: function(data){
		$.each(data,function(index,value){
			var newLi=$("<li class='casebox'></li>");
			var newDiv1=$("<div class='caseImg'></div>");
			var newDiv2=$("<div class='caseTitle'></div>");
			var newDiv3=$("<div class='caseText'></div>");
			$(".caseList ul").append(newLi);
			newLi.append(newDiv1,newDiv2,newDiv3);
			var newImg1=$("<img src='images/"+value.hotelImg+"'>")
			newDiv1.append(newImg1);
			var newSpan=$("<span class='caseName'>"+value.hotelName+"</span>");
			var newImg2=$("<img src='../images/mores.png'>");
			newDiv2.append(newSpan,newImg2);
			var newP=$("<p>"+value.hotelIntro+"</p>");
			newDiv3.append(newP);
		})
		$(".caseTitle").eq(0).css({
			backgroundColor: "#3097CC",
		})
			$(".caseTitle").eq(1).css({
			backgroundColor: "#327DF1",
		})
		$(".caseTitle").eq(2).css({
			backgroundColor: "#3865C3",
		})
		$(".casebox").mouseenter(function(){
		    this.style.cursor="pointer"
		})
	}
})


//合作伙伴读取json文件
$.ajax({
	url: "http://10.10.72.9:8080/hezuo.json",
	success: function(data){
		$.each(data.hezuo,function(index,value){
			var newCorLi=$("<li class='corbox'></li>");
			$(".corList ul").append(newCorLi);
			var newCorImg=$("<img src='images/"+value.src+"'>");
			newCorLi.append(newCorImg);
		})
	}
})


// 案列1跳转页面



$(".caseList").on("click",".casebox",function(){
//	$(this).addClass("caseHref");
	 $(location).prop("href","case1.html");
})


$("footer .container").css({
	backgroundColor: "#f2f2f2"
})



