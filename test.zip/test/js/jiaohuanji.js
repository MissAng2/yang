$(function(){
    $("html,body").animate({scrollTop:"500"},1000)
})
// 了解更多
//$(".readmore").mouseenter(function(){
//  $(this).css({
//      backgroundColor: "#327DF1",
//      color: "#ffffff",
//  })
//})
//$(".readmore").mouseleave(function(){
//  $(this).css({
//      backgroundColor: "#ffffff",
//      color: "#327DF1",
//  })
//})

$(".pro_show").on("mouseenter",".readmore",function(){
	$(this).css({
        backgroundColor: "#327DF1",
        color: "#ffffff",
    })
})
$(".pro_show").on("mouseleave",".readmore",function(){
	$(this).css({
        backgroundColor: "#ffffff",
        color: "#327DF1",
    })
})

// 下划线
$(".tit_name li").eq(0).css({
    borderBottom: "2px solid #327DF1",
    color: "#327DF1"
})
$(".tit_name li").click(function(){
    $(this).css({
        borderBottom: "2px solid #327DF1",
        color: "#327DF1"
    }).siblings().css({
        border: "none",
        color: "#78828C",
    })
})
// 鼠标箭头样式
$(".tit_name li").mouseenter(function(){
    this.style.cursor="pointer"
})
//$(".pagelist li").mouseenter(function(){
//  this.style.cursor="pointer"
//})

$(".pagelist").on("mouseenter","li",function(){
	this.style.cursor="pointer"
})

// 分页按钮样式
//$(".pagenav").eq(2).css({
//  color: "#fff",
//  backgroundColor: "#327DF1",
//})
//$(".pagenav").eq(3).css({
//  color: "#666",
//})
//$(".pagenav").eq(4).css({
//  color: "#666",
//})
//$(".pagenav").eq(5).css({
//  color: "#666",
//})

// 跳转
//$(".pagelist li").eq(3).click(function(){
//  $(location).prop("href","jiaohuanji2.html");
//})
//$(".pagelist li").eq(4).click(function(){
//  $(location).prop("href","jiaohuanji2.html");
//})
//$(".pagelist li").eq(5).click(function(){
//  $(location).prop("href","jiaohuanji2.html");
//})



$.ajax({
	url: "http://10.10.72.9:8080/jiaohuanji.json",
	success: function(data){
		// 获取记录条数
		var length=data.length;
		// 一页显示9条
		var pageLen=9;
		//页数
		var pageNum=Math.ceil(length/pageLen);
		console.log(pageNum);
		
		
		//分页的页码
		var num;
		for(num=pageNum;num>=1;num--){
			for(var i=0;i<pageNum;i++){
				var newPageLi=$("<li>"+num+"</li>");
			}
			$(".pagelist li").eq(1).after(newPageLi);
		}
		console.log($(".pagelist li"));
		
		//默认状态
		//第一页激活
		$(".pagelist li").eq(2).css({
			color: "#FFFFFF",
			backgroundColor: "#327DF1",
		}).addClass("btnActive").attr("disabled","disabled");
		//后面的可以点击
		for(var t=$(".pagelist li").length-1; t>2; t--){
			$(".pagelist li").eq(t).css({
				color: "#666666",
				backgroundColor: "#f0f2f5",
			}).attr("disabled",false);
		}
		//前面的不可以点击
		for(var t=0;t<2;t++){
			$(".pagelist li").eq(t).css({
				color: "#c0c4cc",
				backgroundColor: "#f0f2f5",
			}).attr("disabled","disabled");
		}
		

		$.each(data,function(index,value){
			function insert(){
				var newProLi=$("<li class='pro_list'></li>");
				$(".pro_show ul").append(newProLi);
				var proImgDiv=$("<div class='pro_img'></div>");
				var proNameDiv=$("<div class='pro_name'>"+value.JHName+"</div>");
				var proTextDiv=$("<div class='pro_text'>"+value.JHIntro+"</div>");
				var proMoreDiv=$("<div class='readmore'>了解更多</div>");
				newProLi.append(proImgDiv,proNameDiv,proTextDiv,proMoreDiv);
				var proImage=$("<img src='images/"+value.JHImg+"'>");
				proImgDiv.append(proImage);
				proImage.css({
					width: '200px',
				})
			}
			var j=0;
			if(index>=j*pageLen && index<pageLen+j*pageLen){
				insert();
			}
		
		})
		
		
		$(".pagelist li").click(function(){
			var res=[];
			res.push($(this).index());
			console.log(res)
			
			$("html,body").animate({scrollTop:"500"},1000);
//			$(".pagelist li").eq($(".pagelist li").length-3).addClass("btnActive").removeClass("btnAble").removeClass("unable");
//			for(var t=$(".pagelist li").length-2; t<$(".pagelist li").length; t++){
//				$(".pagelist li").eq(t).addClass("unable").removeClass("btnAble").removeClass("btnActive");
//			}					
//			for(var t=0;t<$(".pagelist li").length-3;t++){
//				$(".pagelist li").eq(t).addClass("btnAble").removeClass("unable").removeClass("btnActive");
//			}
//			$(this).addClass("btnActive").removeClass("btnAble").removeClass("unable");
//			for(var t=$(".pagelist li").length-2; t<$(".pagelist li").length; t++){
//				$(".pagelist li").eq(t).addClass("unable").removeClass("btnAble").removeClass("btnActive");
//			}					
//			for(var t=0;t<$(".pagelist li").length-3;t++){
//				$(".pagelist li").eq(t).addClass("btnAble").removeClass("unable").removeClass("btnActive");
//			}

			var pageIndex=res[res.length-1];
			var j;
			console.log(pageIndex)
			// 最后一页/最后
			if(pageIndex==$(".pagelist li").length-3 || pageIndex==$(".pagelist li").length-1){
				console.log("33")
				//最后一页激活
				$(".pagelist li").eq($(".pagelist li").length-3).css({
					color: "#FFFFFF",
					backgroundColor: "#327DF1",
				}).addClass("btnActive").attr("disabled","disabled");
				// 后面的不可以点击
				for(var t=$(".pagelist li").length-2; t<$(".pagelist li").length; t++){
					$(".pagelist li").eq(t).css({
						color: "#c0c4cc",
						backgroundColor: "#f0f2f5",
					}).removeClass().attr("disabled","disabled");
				}
				//前面的可以点击
				for(var t=0; t<$(".pagelist li").length-3; t++){
					$(".pagelist li").eq(t).css({
						color: "#666666",
						backgroundColor: "#f0f2f5",
					}).removeClass().attr("disabled",false);
				}
				j=$(".pagelist li").length-5;
				$(".pro_show li").remove();
				$.each(data,function(index,value){
					function insert(){
						var newProLi=$("<li class='pro_list'></li>");
						$(".pro_show ul").append(newProLi);
						var proImgDiv=$("<div class='pro_img'></div>");
						var proNameDiv=$("<div class='pro_name'>"+value.JHName+"</div>");
						var proTextDiv=$("<div class='pro_text'>"+value.JHIntro+"</div>");
						var proMoreDiv=$("<div class='readmore'>了解更多</div>");
						newProLi.append(proImgDiv,proNameDiv,proTextDiv,proMoreDiv);
						var proImage=$("<img src='images/"+value.JHImg+"'>");
						proImgDiv.append(proImage);
						proImage.css({
							width: '200px',
						})	
					}
					if(index>=j*pageLen && index<pageLen+j*pageLen){
						insert();
					}
				})
			}
			//下一页
			else if(pageIndex==$(".pagelist li").length-2){
				console.log("点击下一页")
				var activeIndex=$(".btnActive").index();
				j=activeIndex-1;
				// 激活的按钮在1-最后
				if(activeIndex>=2 && activeIndex<$(".pagelist li").length-2){
					console.log("1111")
					console.log(activeIndex)
					// activeIndex的下一个激活
					$(".pagelist li").eq(activeIndex+1).css({
						color: "#FFFFFF",
						backgroundColor: "#327DF1",
					}).addClass("btnActive").attr("disabled","disabled");
					
					//前面的都可点
					$(".pagelist li").eq(activeIndex+1).prevAll().css({
						color: "#666666",
						backgroundColor: "#f0f2f5",
					}).removeClass("btnActive").attr("disabled",false);
					
					if(activeIndex==$(".pagelist li").length-4){
						console.log("2222")
						// activeIndex激活
						$(".pagelist li").eq(activeIndex).css({
							color: "#FFFFFF",
							backgroundColor: "#327DF1",
						}).addClass("btnActive").attr("disabled","disabled");
						//后面的不可以点
						$(".pagelist li").eq(activeIndex+1).nextAll().css({
							color: "#c0c4cc",
							backgroundColor: "#f0f2f5",
						}).removeClass("btnActive").attr("disabled","disabled");
						//前面的可以点
						$(".pagelist li").eq(activeIndex+1).prevAll().css({
							color: "#666666",
							backgroundColor: "#f0f2f5",
						}).removeClass("btnActive").attr("disabled",false);
					}

				}
				$(".pro_show li").remove();
				$.each(data,function(index,value){
					function insert(){
						var newProLi=$("<li class='pro_list'></li>");
						$(".pro_show ul").append(newProLi);
						var proImgDiv=$("<div class='pro_img'></div>");
						var proNameDiv=$("<div class='pro_name'>"+value.JHName+"</div>");
						var proTextDiv=$("<div class='pro_text'>"+value.JHIntro+"</div>");
						var proMoreDiv=$("<div class='readmore'>了解更多</div>");
						newProLi.append(proImgDiv,proNameDiv,proTextDiv,proMoreDiv);
						var proImage=$("<img src='images/"+value.JHImg+"'>");
						proImgDiv.append(proImage);
						proImage.css({
							width: '200px',
						})	
					}
					if(index>=j*pageLen && index<pageLen+j*pageLen){
						insert();
					}
				})
			}
			//第一页/开始
			else if(pageIndex==2||pageIndex==0){
				console.log("11")
				//第一页激活
				$(".pagelist li").eq(2).css({
						color: "#FFFFFF",
						backgroundColor: "#327DF1",
					}).addClass("btnActive").attr("disabled","disabled");
				//前两个不可以点
				for(var t=0; t<2; t++){
					$(".pagelist li").eq(t).css({
						color: "#c0c4cc",
						backgroundColor: "#f0f2f5",
					}).removeClass().attr("disabled","disabled");
				}
				for(var t=3; t<$(".pagelist li").length; t++){
					$(".pagelist li").eq(t).css({
						color: "#666666",
						backgroundColor: "#f0f2f5",
					}).removeClass().attr("disabled",false);
				}
				j=0;
				$(".pro_show li").remove();
				$.each(data,function(index,value){
					function insert(){
						var newProLi=$("<li class='pro_list'></li>");
						$(".pro_show ul").append(newProLi);
						var proImgDiv=$("<div class='pro_img'></div>");
						var proNameDiv=$("<div class='pro_name'>"+value.JHName+"</div>");
						var proTextDiv=$("<div class='pro_text'>"+value.JHIntro+"</div>");
						var proMoreDiv=$("<div class='readmore'>了解更多</div>");
						newProLi.append(proImgDiv,proNameDiv,proTextDiv,proMoreDiv);
						var proImage=$("<img src='images/"+value.JHImg+"'>");
						proImgDiv.append(proImage);
						proImage.css({
							width: '200px',
						})	
					}
					if(index>=j*pageLen && index<pageLen+j*pageLen){
						insert();
					}
				})
			}
			//上一页
			else if(pageIndex==1){
				console.log("点击上一页")
				var activeIndex=$(".btnActive").index();
				console.log(activeIndex)
				j=activeIndex-3;
				// 激活的按钮在第二页-最后一页
				if(activeIndex>=2 && activeIndex<$(".pagelist li").length-2){
					console.log("1111")
					console.log(activeIndex)
					// activeIndex的上一个激活
					$(".pagelist li").eq(activeIndex-1).css({
						color: "#FFFFFF",
						backgroundColor: "#327DF1",
					}).addClass("btnActive").attr("disabled","disabled");
					
					//后面的都可点
					$(".pagelist li").eq(activeIndex-1).nextAll().css({
						color: "#666666",
						backgroundColor: "#f0f2f5",
					}).removeClass("btnActive").attr("disabled",false);
					
					if(activeIndex==3){
						console.log("2222")
						// activeIndex激活
						$(".pagelist li").eq(activeIndex).css({
							color: "#FFFFFF",
							backgroundColor: "#327DF1",
						}).addClass("btnActive").attr("disabled","disabled");
						$(".pagelist li").eq(activeIndex-1).prevAll().css({
							color: "#c0c4cc",
							backgroundColor: "#f0f2f5",
						}).removeClass("btnActive").attr("disabled","disabled");
						$(".pagelist li").eq(activeIndex-1).nextAll().css({
							color: "#666666",
							backgroundColor: "#f0f2f5",
						}).removeClass("btnActive").attr("disabled",false);
					}

				}
				$(".pro_show li").remove();
				$.each(data,function(index,value){
					function insert(){
						var newProLi=$("<li class='pro_list'></li>");
						$(".pro_show ul").append(newProLi);
						var proImgDiv=$("<div class='pro_img'></div>");
						var proNameDiv=$("<div class='pro_name'>"+value.JHName+"</div>");
						var proTextDiv=$("<div class='pro_text'>"+value.JHIntro+"</div>");
						var proMoreDiv=$("<div class='readmore'>了解更多</div>");
						newProLi.append(proImgDiv,proNameDiv,proTextDiv,proMoreDiv);
						var proImage=$("<img src='images/"+value.JHImg+"'>");
						proImgDiv.append(proImage);
						proImage.css({
							width: '200px',
						})	
					}
					if(index>=j*pageLen && index<pageLen+j*pageLen){
						insert();
					}
				})
			}
			else if(pageIndex>2&&pageIndex<$(".pagelist li").length-3){
				console.log("55")
				for(var t=2;t<$(".pagelist li").length-2;t++){
					$(".pagelist li").eq(t).css({
						color: "#666666",
						backgroundColor: "#f0f2f5",
					}).removeClass().attr("disabled",false);
				}
				$(".pagelist li").eq(pageIndex).css({
						color: "#FFFFFF",
						backgroundColor: "#327DF1",
					}).addClass("btnActive").attr("disabled","disabled");
				for(var t=0; t<2; t++){
					$(".pagelist li").eq(t).css({
						color: "#666666",
						backgroundColor: "#f0f2f5",
					}).removeClass().attr("disabled",false);
				}
				for(var t=$(".pagelist li").length-2; t<$(".pagelist li").length; t++){
					$(".pagelist li").eq(t).css({
						color: "#666666",
						backgroundColor: "#f0f2f5",
					}).removeClass().attr("disabled",false);
				}
				j=pageIndex-2;
				$(".pro_show li").remove();
				$.each(data,function(index,value){
					function insert(){
						var newProLi=$("<li class='pro_list'></li>");
						$(".pro_show ul").append(newProLi);
						var proImgDiv=$("<div class='pro_img'></div>");
						var proNameDiv=$("<div class='pro_name'>"+value.JHName+"</div>");
						var proTextDiv=$("<div class='pro_text'>"+value.JHIntro+"</div>");
						var proMoreDiv=$("<div class='readmore'>了解更多</div>");
						newProLi.append(proImgDiv,proNameDiv,proTextDiv,proMoreDiv);
						var proImage=$("<img src='images/"+value.JHImg+"'>");
						proImgDiv.append(proImage);
						proImage.css({
							width: '200px',
						})	
					}
					if(index>=j*pageLen && index<pageLen+j*pageLen){
						insert();
					}
				})
			}
			
		})
		
//		for(var t=0;t<3;t++){
//			$(".pagelist li").eq(t).click(function(){
//				$("html,body").animate({scrollTop:"500"},1000);
//				$(".pagelist li").eq(2).addClass("btnActive").removeClass("btnAble").removeClass("unable");
//				for(var t=$(".pagelist li").length-1; t>2; t--){
//					$(".pagelist li").eq(t).addClass("btnAble").removeClass("btnActive").removeClass("unable");
//				}					
//				for(var t=0;t<2;t++){
//					$(".pagelist li").eq(t).addClass("unable").removeClass("btnAble").removeClass("btnActive");
//				}
//				$(".pro_show li").remove();
//				$.each(data,function(index,value){
//					function insert(){
//						var newProLi=$("<li class='pro_list'></li>");
//						$(".pro_show ul").append(newProLi);
//						var proImgDiv=$("<div class='pro_img'></div>");
//						var proNameDiv=$("<div class='pro_name'>"+value.JHName+"</div>");
//						var proTextDiv=$("<div class='pro_text'>"+value.JHIntro+"</div>");
//						var proMoreDiv=$("<div class='readmore'>了解更多</div>");
//						newProLi.append(proImgDiv,proNameDiv,proTextDiv,proMoreDiv);
//						var proImage=$("<img src="+value.JHImg+">");
//						proImgDiv.append(proImage);
//						proImage.css({
//							width: '200px',
//						})	
//					}
//					var j=0;
//					if(index>=j*pageLen && index<pageLen+j*pageLen){
//						insert();
//					}
//				})
//			})
//		}
			
	}
		
//	}
})
